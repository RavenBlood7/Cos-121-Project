/* 
 * File:   Goblin.cpp
 * Author: merissa
 *
 * Created on 07 October 2015, 10:33 AM
 */
#include "Goblin.h"
Goblin::Goblin():Piercing(50,12,"Piercing")
{
    
}