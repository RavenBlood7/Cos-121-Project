/* 
 * File:   Thief.cpp
 * Author: merissa
 *
 * Created on 07 October 2015, 10:32 AM
 */
#include "Thief.h"
Thief::Thief():Piercing(60,10,"Piercing")
{
    
}
