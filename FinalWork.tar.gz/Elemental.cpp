/* 
 * File:   Elemental.cpp
 * Author: merissa
 *
 * Created on 07 October 2015, 10:31 AM
 */
#include "Elemental.h"
Elemental::Elemental():Magic(85,4,"Magic")
{
    
}
