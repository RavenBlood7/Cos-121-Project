/* 
 * File:   main.cpp
 * Author: merissa
 *
 * Created on 06 October 2015, 4:31 PM
 */

#include <cstdlib>
#include "GamePlay.h"

#include <iostream>

using namespace std;
 
int main(int argc, char** argv) 
{
	GamePlay newGame;
	newGame.play();
	return 0;
}

