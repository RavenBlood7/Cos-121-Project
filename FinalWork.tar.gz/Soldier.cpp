/* 
 * File:   Soldier.cpp
 * Author: merissa
 *
 * Created on 07 October 2015, 10:31 AM
 */
#include "Soldier.h"
Soldier::Soldier():Bludgeoning(100,8,"Bludgeoning")
{
    
}
