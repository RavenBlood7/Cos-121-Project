/* 
 * File:   Ogre.cpp
 * Author: merissa
 *
 * Created on 07 October 2015, 10:32 AM
 */
#include "Ogre.h"
Ogre::Ogre():Bludgeoning(120,5,"Bludgeoning")
{
    
}
