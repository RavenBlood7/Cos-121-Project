/* 
 * File:   Mage.cpp
 * Author: merissa
 *
 * Created on 07 October 2015, 10:30 AM
 */
#include "Mage.h"
Mage::Mage():Magic(80,5,"Magic")
{
    
}